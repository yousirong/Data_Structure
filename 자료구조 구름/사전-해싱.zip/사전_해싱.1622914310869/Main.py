#                1.제목:한국외대 자료구조 과제 6(6-1-1)
#                2.날짜:20210605
# 사전 해싱
class DoubleHashing:
    def __init__(self, size):
        self.M = size
        self.hash_table = [None for x in range(size+1)]  # hashtable
        self.data = [None for x in range(size+1)]  # key관련 data저장
        self.N = 0  # 항목수

    def getkey(self, key):
        self.key = ord(key[0])
        return self.key

    def hash_func(self, key):
        return key % self.M

    def getAddress(self, key):
        myKey = self.getkey(key)
        hash_address = self.hash_func(myKey)
        return hash_address

    def put(self, key, data):  # insert
        init_num = self.getAddress(key)  # 초기 위치
        i = init_num
        second_i = 7 - (self.getkey(key) % 7)  # hash 2
        j = 0
        while True:
            if self.hash_table[i] == None:  # 삽입 위치 찾기
                self.hash_table[i] = key  # key를 해쉬 테이블에 저장
                self.data[i] = data  # key값이 데이터를 동일한 인덱스에 저장
                self.N += 1
                return True
            elif self.hash_table[i] != None:
                if self.hash_table[i] == key:
                    return print("error1")
            if self.hash_table[i] == key:
                self.data[i] = data  # data 갱신
                return True
            j += 1
            i = (init_num + j*second_i) % self.M  # 이중해쉬 하는 부분
            if self.N > self.M:  # 테이블이 꽉찰 경우
                break
        return print("error1")

    def get(self, key):  # 탐색
        init_num = self.getAddress(key)
        i = init_num
        second_i = 7 - (self.getkey(key) % 7)
        j = 0
        while self.hash_table[i] != None:
            if self.hash_table[i] == key:
                return self.data[i]
            j += 1
            i = (init_num + j*second_i) % self.M
        return print("error2")

    def correct(self, key, data):
        init_num = self.getAddress(key)
        i = init_num
        second_i = 7 - (self.getkey(key) % 7)
        j = 0
        while self.hash_table[i] != None:
            if self.hash_table[i] == key:
                self.data[i] = data
                return
            j += 1
            i = (init_num + j * second_i) % self.M
        return print("error2")

    def print_table(self):
        for i in range(self.M):
            if self.hash_table[i] == None:
                pass
            else:
                print(str(self.hash_table[i]) + str(self.data[i]))



h = DoubleHashing(13)
while True:
    command = input().split()
    #print(command)
    if command[0] == '단어삽입':
        h.put(command[1], command[2])
    elif command[0] == '단어뜻수정':
        h.correct(command[1], command[2])
    elif command[0] == '단어검색':
        print(h.get(command[1]))
    elif command[0] == 'p':
        h.print_table()
    elif command[0] == '종료':  # 종료
        break