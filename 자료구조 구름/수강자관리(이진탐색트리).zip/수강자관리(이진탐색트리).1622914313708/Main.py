#                1.제목:한국외대 자료구조 과제 5(5-1-1)
#                2.날짜:20210521
# 5-1-1) 교과목 수강자 관리를 위한 다음 명령어를 처리하는 프로그램을 작성하시오. 수강자는 학번정보(문자열)를 가진다.

class Node:
    def __init__(self, st_id):
        self.st_id = st_id
        self.left = None
        self.right = None

class BSTree:
    def __init__(self):
        self.root = None   # None으로 변경
        self.inorder_list = []
        self.count = []

    def isempty(self):   # 노드의 개수를 반환 해주는 함수에서 반환 값이 0인 경우
        if self.sizelist() != 0:
            return False  # 비어있지 않음 -> False
        else:
            return True   # 비어있음 ->True

    def insert(self, item):
        if self.root is None:   # insert에 처음 넣을 경우 root는 None이므로 
            self.root = Node(item)   # self.root에 Node(item) 생성
        # root가 있으면 왼쪽배치 or 오른쪽배치
        else:
            self.__insert_node(self.root, item)

        # head가 있는 경우
    def __insert_node(self, node, item):
        # head 값이 크면 왼쪽으로
        if node.st_id >= item:
            if node.left is not None:
                self.__insert_node(node.left, item)
            else:
                node.left = Node(item)
        # head 값이 작으면 오른쪽으로
        elif node.st_id < item:
            if node.right is not None:
                self.__insert_node(node.right, item)
            else:
                node.right = Node(item)
        else:
            return node.st_id

    def delete(self, key):
        self.root, deleted = self._delete_value(self.root, key)
        return deleted

    def _delete_value(self, node, key):
        if node is None:
            return node, False
        deleted = False
        if key == node.st_id:
            deleted = True
            if node.left and node.right:

                parent, child = node, node.right
                while child.left is not None:
                    parent, child = child, child.left
                child.left = node.left
                if parent != node:
                    parent.left = child.right
                    child.right = node.right
                node = child
            elif node.left or node.right:
                node = node.left or node.right
            else:
                node = None
        elif key < node.st_id:
            node.left, deleted = self._delete_value(node.left, key)
        elif key > node.st_id:
            node.right, deleted = self._delete_value(node.right, key)
        return node, deleted

    def print_list(self):
        if self.root is not None:
            self.sizelist(self.root)

    def sizelist(self, res):  # list 크기 반환
        if res.left is not None:
            self.sizelist(res.left)

        self.count.append(res.st_id)

        if res.right is not None:
            self.sizelist(res.right)

    # 오름차순으로 출력 (전위)
    def in_order_traversal(self):
        self.inorder_list = []
        def _in_order_traversal(root):
            if root is None:
                pass
            else:
                _in_order_traversal(root.left)
                # print(root.st_id, end=' ')
                self.inorder_list.append(root.st_id)
                _in_order_traversal(root.right)
        _in_order_traversal(self.root)
        int_li = sorted(self.inorder_list, key=str)
        # int_li = sorted(map(str, self.inorder_list))
        return int_li

classStudents = BSTree()
while True:
    command = input().split()
    if command[0] == 'N':  # st_id(즉, command[1])를 수강자리스트에 insert
        classStudents.insert(command[1])
    elif command[0] == 'C':  # st_id(즉, command[1])를 수강자리스트에서 delete
        classStudents.delete(command[1])
    elif command[0] == 'S':  # 수강자리스트의 원소 수를 출력
        classStudents.count = []
        classStudents.print_list()
        print(len(classStudents.count), end='\n')
    elif command[0] == 'P':  # 수강자리스트의 원소들을 오름차순으로 출력
        arr = classStudents.in_order_traversal()
        for i in arr:
            print(i, end=' ')

    elif command[0] == 'Q':  # 종료
        break