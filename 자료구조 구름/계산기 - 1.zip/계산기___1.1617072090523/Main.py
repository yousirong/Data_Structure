#                1.제목:한국외대 자료구조 과제(계산기)
#                2.날짜:20210327
# 1) 계산기 1
# (a) 계산기를 위한 다음 클래스를 정의하고 구현하시오(파일 이름: calculator1.py).
#
# 자료: 현재 값 (정수)
#
# 연산들
#     __init__() : 현재값을 0으로 초기화한다.
#     setValue(x): 현재 값을 x로 설정.
#     getValue(): 현재 값을 반환함.
#     add(x): 현재 값에 x를 더한 값이 현재 값이 된다.
#     sub(x): 현재 값에서 x를 뺀 값이 현재 값이 된다.
#     mpy(x): 현재 값에 x를 곱한 값이 현재 값이 된다.
#     div(x): 현재 값을 x로 나눈 몫이 현재 값이 된다.
#     mod(x): 현재 값을 x로 나눈 나머지가 현재 값이 된다.
#     clear(): 현재 값을 0으로 한다.

class Calculator:
    def __init__(self):
        self.value = 0
    def getValue(self):
        return self.value
    def setValue(self,num):
        self.value = num
    def add(self,num):
        self.value += num
    def sub(self,num):
        self.value -= num
    def mpy(self,num):
        self.value *= num
    def div(self,num):
        self.value //= num
    def mod(self,num):
        self.value %= num
    def clear(self):
        self.value = 0

# from calculator1 import Calculator
cal = Calculator()

while True:
    command = input().split()
    if command[0] == 'add':
        cal.add(int(command[1]))
    elif command[0] == 'sub':
        cal.sub(int(command[1]))
    elif command[0] == 'currentValue':
        print(cal.getValue())
    elif command[0] == 'mpy':
        cal.mpy(int(command[1]))
    elif command[0] == 'div':
        cal.div(int(command[1]))
    elif command[0] == 'mod':
        cal.mod(int(command[1]))
    elif command[0] == 'clear':
        cal.clear()
    elif command[0] == 'setValue':
        cal.setValue(int(command[1]))
    elif command[0] == 'quit':
        break