#                1.제목:한국외대 자료구조 과제(계산기)
#                2.날짜:20210327
# 2) 계산기 2
# (a) 계산기를 위한 다음 클래스를 정의하고 구현하시오(파일 이름: calculator2.py).
#
# 자료:  현재 값 (정수)
#        메모리에 저장한 값 (정수)
# 연산들:
# setValue(x): 현재 값을 x로 설정.
# getValue(): 현재 값을 반환함.
# add(x): 현재 값에 x를 더한 값이 현재 값이 된다.
# sub(x): 현재 값에서 x를 뺀 값이 현재 값이 된다.
# mpy(x): 현재 값에 x를 곱한 값이 현재 값이 된다.
# div(x): 현재 값을 x로 나눈 몫이 현재 값이 된다.
# mod(x): 현재 값을 x로 나눈 나머지가 현재 값이 된다.
# changeSign(): 현재 값의 부호를 바꾼다.
# clear(): 현재 값을 0으로 함.
# memorySave: 현재 값을 메모리에 저장 (현재 값을 메모리 값으로 설정). 'MS'
# memoryRead: 메모리에 있는 값을 현재 값으로 설정함 (현재 값이 변함). 'MR'
# memoryClear: 메모리에 저장된 값을 0으로 둠 (현재 값은 변하지 않음). 'MC'
# memoryAdd : 메모리에 저장되어 있는 값에 현재 값을 더하여, 그 결과 값을 메모리에 저장한 값으로 둠 (현재 값은 변하지 않음). 'M+'
# memorySub : 메모리에 저장되어 있는 값에서 현재 값을 빼서, 그 결과 값을 메모리에 저장한 값으로 둠 (현재 값은 변하지 않음). 'M-'
# (2) 위의 클래스를 이용하여 (import 사용) 다음과 같은 계산기 명령어를 처리하는 응용 프로그램을 작성하시오.
class Calculator:
    def __init__(self):
        self.value = 0
        self.memory = 0
    def setValue(self,num):
        self.value = num
    def getValue(self):
        return self.value
    def add(self,num):
        self.value += num
    def sub(self,num):
        self.value -= num
    def mpy(self,num):
        self.value *= num
    def div(self,num):
        self.value //= num
    def mod(self,num):
        self.value %= num
    def changeSign(self):
        self.value = -(self.value)
        # if(self.vlaue < 0):
        #     return -self.vlaue
        # elif(self.vlaue > 0):
        #     return -self.vlaue
        # elif(self.vlaue == 0):
        #     return self.vlaue
    def clear(self):
        self.value = 0
    def memorySave(self):
        self.memory = self.value
    def memoryRead(self):
        self.value = self.memory
    def memoryClear(self):
        self.memory = 0
    def memoryAdd(self):
        self.memory = self.memory + self.value
    def memorySub(self):
        self.memory = self.memory - self.value

# from calculator2 import Calculator
cal = Calculator()

while True:
    command = input().split()
    if command[0] == 'add':
        cal.add(int(command[1]))
    elif command[0] == 'sub':
        cal.sub(int(command[1]))
    elif command[0] == 'currentValue':
        print(cal.getValue())
    elif command[0] == 'mpy':
        cal.mpy(int(command[1]))
    elif command[0] == 'div':
        cal.div(int(command[1]))
    elif command[0] == 'mod':
        cal.mod(int(command[1]))
    elif command[0] == 'cs':
        cal.changeSign()
    elif command[0] == 'clear':
        cal.clear()
    elif command[0] == 'setValue':
        cal.setValue(int(command[1]))
    elif command[0] == 'MS':
        cal.memorySave()
    elif command[0] == 'MR':
        cal.memoryRead()
    elif command[0] == 'MC':
        cal.memoryClear()
    elif command[0] == 'M+':
        cal.memoryAdd()
    elif command[0] == 'M-':
        cal.memorySub()
    elif command[0] == 'quit':
        break
